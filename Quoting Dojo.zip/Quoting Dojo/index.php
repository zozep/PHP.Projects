<!doctype html>
<html>
<head>
	<title></title>
	<link rel="styleshset" type="text/css" href="style.css">
	<meta charset="utf-8">
</head>
<body>
	<div id="container">
		<div>
			<h1>welcome to quoting dojo</h1>
			
			<form method="post" action="process.php">
				<label>Your Name: <input type-"text" name="name"></label>
				<label>Your quote:</label>
					<textarea rows="10" sols="40" name="quote"></textarea>
				</label>
				<input type="submit" value="Add!">
				<br>
				<br>
				<a href="main.php">Skip to Quotes!</a>
			</form>
		</div>
	</div>
</body>
</html>